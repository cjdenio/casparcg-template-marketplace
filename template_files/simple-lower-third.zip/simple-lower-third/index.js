var lower_third = document.getElementById("lower_third");

function play(){
    lower_third.style.transform = "translateX(0)";
}

function stop(){
    lower_third.style.transform = "translateX(-150%)";
}

function update(data){
    data = JSON.parse(data);
    text = data.text;
    if(text == undefined){
        lower_third.innerText = "Text is undefined.";
    }
    else if(text == null){
        lower_third.innerText = "Text is null.";
    }
    else{
        lower_third.innerText = text;
    }

    // Font
    if(data.font == undefined){
        lower_third.style.fontFamily = "sans-serif";
    }
    else{
        lower_third.style.fontFamily = data.font;
    }

    // Color
    if (data.color == undefined) {
        lower_third.style.color = "black";
    }
    else {
        lower_third.style.color = data.color;
    }

    // BG Color
    if (data.background_color == undefined) {
        lower_third.style.backgroundColor = "white";
    }
    else {
        lower_third.style.backgroundColor = data.background_color;
    }

    // Font weight
    if (data.font_weight == undefined) {
        lower_third.style.fontWeight = "normal";
    }
    else {
        lower_third.style.fontWeight = data.font_weight;
    }
}